Prerequisite :
-> Python

Command to run :
-> python a.py

Inputs :

First input an integer from {1, 3, 5} which gives the sampling percentage
Then give a string from {nearest, linear} which specifies the interpolation method

example :

->python a.py
Enter sampling percentage : 1
Enter method (linear/nearest):nearest
Total time required for interpolation : 4.332664489746094
Signal to Noise Ratio : 33.87085419665887
