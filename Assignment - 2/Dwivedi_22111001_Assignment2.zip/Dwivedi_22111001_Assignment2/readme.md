Package required-
vtk (if not installed just write pip install vtk)

There are two file a2_1.py and a2_2.py containing code for Question 1 and Question 2 respectively

1. Steps to run the first question of the assignment :

Enter the following command in cmd (in the directory of assignment) to run the python code :
python a2_1.py
User input : Enter an integer value to set the isovalue and press enter

Output : After that a screen with heading 'Contour Line' will popup rendering the contour line
Also a file named contour.vtp will be saved in the same(current) directory which we can open in paraview software

2. Steps to run the second question of the assignment :

Enter the following command in cmd (in the directory of assignment) to run the python code :
python a2_2.py
User input : for yes input 'Y' or 'y' without quotes, for no input 'n' or 'N' without quotes

Output : After that a screen will popup rendering the 3D data with heading 'With phong shading' or 'Without phong shading', which depends on the user input
